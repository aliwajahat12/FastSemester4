# Topics discussed After Mid 1

1. Discrete / Continuous Random variables
   - Probability distribution, 
   - probability mass function (PMF)
   - Cumulative Dist Function (CDF)
   - Probability graph
   - Joint distribution for 2 discrete random variables (JPMF)
   - Marginal distributions, E(X), E(Y), E(XY), Correlation(X,Y). 
2.  Some Discrete distributions: 
    - Binomial
    - Multinomial
    - Hypergeometric
    - Poisson
3. Continuous Dist: 
   - Normal and Standard Normal
   - Z score
   - Areas under the normal curves
   - Z table.

Thank you!